# Stoneburner.Live

Static personal website for GitHub Pages.

## Publish
1. Create a public GitHub repository and upload `index.html`, `CNAME`, and the `assets` directory, preserving paths.
2. In Settings → Pages, select Deploy from a branch → main → /(root).
3. Configure the DNS for `stoneburner.live` with your registrar using GitHub Pages' current custom-domain instructions. Enable HTTPS once the certificate is ready.
4. Set `scottstoneburner.com` to redirect to `https://stoneburner.live` through your domain registrar or redirect hosting provider.

## Before publishing
- The email `hello@stoneburner.live` in the Connect section is a placeholder. Replace it with a working address or form URL.
- Add exact Instagram, LinkedIn, X and SoundCloud links once available.
- The site uses Google Fonts and links to external sites; it otherwise runs as static HTML with local images.
- Confirm permission to publish any portraits featuring other people.
